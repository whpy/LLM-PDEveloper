# structure of src/
```shell
.
|-src
|  |-base.py
|  |-boundary_conditions.py
|  |-lattice.py
|  |-models.py
|  |-utils.py
|-test.py
```