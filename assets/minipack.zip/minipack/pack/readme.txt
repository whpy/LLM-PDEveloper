workflow_v2 is claude
workflow_v3 is claude with physical evaluation

refrac_fw2 is o1 
refrac_fw3 is o1 with physical evaluation

benchmark stores the physical benchmark of advection diffusion
